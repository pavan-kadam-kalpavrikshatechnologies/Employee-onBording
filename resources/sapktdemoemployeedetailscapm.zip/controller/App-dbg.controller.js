sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sap.kt.demo.employeedetailscapm.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  